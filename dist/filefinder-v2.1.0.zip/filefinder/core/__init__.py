"""Application orchestration helpers."""


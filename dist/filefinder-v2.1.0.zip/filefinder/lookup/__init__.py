"""Hash lookup helpers."""


python cli.py
pause
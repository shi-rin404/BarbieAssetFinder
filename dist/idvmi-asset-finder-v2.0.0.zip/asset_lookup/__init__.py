"""Built-in asset lookup and extraction helpers for remote NeoX imports."""

__version__ = "2.0.0"
__api_version__ = 1
